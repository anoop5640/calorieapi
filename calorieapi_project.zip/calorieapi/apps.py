from django.apps import AppConfig


class CalorieapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'calorieapi'
